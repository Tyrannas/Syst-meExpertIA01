java systexp
clisp Sysexp.lisp
